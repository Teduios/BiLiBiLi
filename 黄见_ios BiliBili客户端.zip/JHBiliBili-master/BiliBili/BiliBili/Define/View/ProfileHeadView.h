//
//  ProfileHeadView.h
//  BiliBili
//
//  Created by apple-jd44 on 15/11/20.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  侧边栏顶视图
 */
@interface ProfileHeadView : UIView

@end
