//
//  ShiBanTableViewCell.m
//  BiliBili
//
//  Created by apple-jd44 on 15/11/25.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import "ShiBanEpisodesTableViewCell.h"
#import "ShinBanInfoModel.h"
#import "VideoViewController.h"
@interface ShiBanEpisodesTableViewCell ()
@end

@implementation ShiBanEpisodesTableViewCell

- (void)setEpisodes:(NSArray *)episodes{
    _episodes = episodes;
    __block UIButton *preButton = nil;
    [_episodes enumerateObjectsUsingBlock:^(episodesModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIButton * button = [self viewWithTag: 100 + idx];
        //没添加的情况
        if (button == nil) {
            button = [[UIButton alloc] init];
            //记录下标
            button.tag = 100 + idx;
            button.titleLabel.font = [UIFont systemFontOfSize: 13];
            [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [button setBackgroundImage:[UIImage imageNamed:@"bg_text_field_mono_light_gray_boarder"] forState:UIControlStateNormal];
            
            [button bk_addEventHandler:^(id sender) {
                self.returnBlock(@(button.tag - 100));
            //通知更新按钮标题
                NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
                NSDictionary *userInfo =@{@"title":@(button.tag - 100)};
                [center postNotificationName:@"Update" object:self userInfo:userInfo];
                
            } forControlEvents:UIControlEventTouchUpInside];
            
            [self.vc.view addSubview: button];
            //第一个按钮
            if (preButton == nil) {
                CGFloat rr =  (kWindowW  - 50) / 4;
                [button mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.mas_offset(10);
                    make.top.mas_offset(10);
                    make.width.mas_equalTo(rr);
                }];
                //其它情况
            }else{
                //换行
                if (idx % 4 == 0) {
                    [button mas_makeConstraints:^(MASConstraintMaker *make) {
                        make.left.mas_offset(10);
                        make.width.height.equalTo(preButton);
                        make.top.mas_equalTo(preButton.mas_bottom).mas_offset(10);
                    }];
                }else{
                    [button mas_makeConstraints:^(MASConstraintMaker *make) {
                        make.left.mas_equalTo(preButton.mas_right).mas_offset(10);
                        make.width.height.top.equalTo(preButton);
                    }];
                }
            }
            preButton = button;
        }
        //已经添加的情况
        [button setTitle: obj.index forState:UIControlStateNormal];
        [button setTitleColor:[[ColorManager shareColorManager] colorWithString:@"textColor"] forState:UIControlStateNormal];
    }];
   
    [preButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_offset(-10);
    }];
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}


- (UIViewController *) vc{
    if(_vc == nil) {
        _vc = [[UIViewController alloc] init];
        [self addSubview: _vc.view];
        [_vc.view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _vc;
}

- (void)setUpdateReturnBlock:(updateEpisode)block{
    self.returnBlock = block;
}

@end
