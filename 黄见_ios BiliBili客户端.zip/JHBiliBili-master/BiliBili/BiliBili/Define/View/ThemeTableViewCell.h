//
//  ThemeTableViewCell.h
//  BiliBili
//
//  Created by JimHuang on 15/11/23.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThemeTableViewCell : UITableViewCell
- (instancetype)initWithTitle:(NSString*)title reuseIdentifier:(NSString*)reuseIdentifier;
@end
