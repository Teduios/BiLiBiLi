//
//  ProfileTableViewController.h
//  BiliBili
//
//  Created by apple-jd44 on 15/11/19.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTableViewController.h"
/**
 *  侧边栏视图
 */
@interface ProfileTableViewController : BaseTableViewController
@end
