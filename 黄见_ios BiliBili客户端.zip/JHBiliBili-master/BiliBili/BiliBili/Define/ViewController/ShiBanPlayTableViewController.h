//
//  ShiBanPlayTableViewController.h
//  BiliBili
//
//  Created by apple-jd44 on 15/11/26.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

/**
 *  新番放松表
 */
#import <UIKit/UIKit.h>

@interface ShiBanPlayTableViewController : UITableViewController

@end
