//
//  ThemeTableViewController.h
//  BiliBili
//
//  Created by JimHuang on 15/11/23.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTableViewController.h"

@interface ThemeTableViewController : UITableViewController

@end
