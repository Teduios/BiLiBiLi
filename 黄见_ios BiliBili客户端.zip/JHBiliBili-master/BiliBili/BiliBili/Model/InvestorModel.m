//
//  InvestorModel.m
//  BiliBili
//
//  Created by apple-jd44 on 15/11/6.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import "InvestorModel.h"

@implementation InvestorModel
+ (NSDictionary *)objectClassInArray{
    return @{@"list":[InvestorDataModel class]};
}
@end


@implementation InvestorDataModel


@end