//
//  ReplyModel.m
//  BiliBili
//
//  Created by apple-jd44 on 15/11/6.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import "ReplyModel.h"

@implementation ReplyModel
+ (NSDictionary*)objectClassInArray{
    return @{@"list":[ReplyDataModel class]};
}
@end


@implementation ReplyDataModel



@end