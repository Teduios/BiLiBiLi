//
//  TagModel.m
//  BiliBili
//
//  Created by apple-jd44 on 15/11/8.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import "TagModel.h"

@implementation TagModel
+ (NSDictionary *)objectClassInArray{
    return @{@"result":[TagDataModel class]};
}
@end

@implementation TagDataModel


@end