//
//  AppDelegate+Category.h
//  BaseProject
//
//  Created by JimHuang on 15/10/21.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (Category)

- (void)initializeWithApplication:(UIApplication *)application;

@end
