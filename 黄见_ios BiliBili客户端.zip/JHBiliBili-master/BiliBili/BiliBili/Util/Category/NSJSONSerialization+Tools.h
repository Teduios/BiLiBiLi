//
//  NSJSONSerialization+Tools.h
//  BiliBili
//
//  Created by apple-jd44 on 15/11/17.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSJSONSerialization (Tools)
+ (id)json2DicWithData:(NSData*)data;
@end
