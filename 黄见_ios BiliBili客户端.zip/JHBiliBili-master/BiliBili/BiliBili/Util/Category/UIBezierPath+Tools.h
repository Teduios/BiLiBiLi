//
//  UIBezierPath+Tools.h
//  tes
//
//  Created by JimHuang on 15/11/22.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBezierPath (Tools)
+ (instancetype)bezierPathWithAIFilePath:(NSString*)path;
@end
