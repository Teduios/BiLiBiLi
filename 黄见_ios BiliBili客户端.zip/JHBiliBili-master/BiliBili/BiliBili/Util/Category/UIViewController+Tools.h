//
//  UIViewController+Tools.h
//  BiliBili
//
//  Created by apple-jd44 on 15/11/11.
//  Copyright © 2015年 JimHuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Tools)
- (UINavigationController*)setupNavigationController;
@end
